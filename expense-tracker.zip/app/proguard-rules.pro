# ClearLedger: Room keeps its entities; everything else may be shrunk.
-keep class com.clearledger.expenses.data.** { *; }
-keep class androidx.room.** { *; }
-dontwarn org.robolectric.**
