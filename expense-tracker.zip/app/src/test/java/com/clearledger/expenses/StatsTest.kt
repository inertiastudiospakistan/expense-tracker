package com.clearledger.expenses

import com.clearledger.expenses.data.Category
import com.clearledger.expenses.data.Expense
import com.clearledger.expenses.data.Stats
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

class StatsTest {

    private fun exp(
        amountMinor: Long, isIncome: Boolean, cat: Category,
        date: LocalDate, note: String = ""
    ) = Expense(
        amountMinor = amountMinor, isIncome = isIncome,
        category = cat.name, dateEpochDay = date.toEpochDay(), note = note
    )

    private val nov2026 = YearMonth.of(2026, 11)
    private val sample = listOf(
        exp(10000, false, Category.FOOD, LocalDate.of(2026, 11, 3), "Groceries"),
        exp(5000, false, Category.FOOD, LocalDate.of(2026, 11, 10)),
        exp(20000, false, Category.HOUSING, LocalDate.of(2026, 11, 1), "Rent"),
        exp(3000, false, Category.TRANSPORT, LocalDate.of(2026, 10, 28)),
        exp(150000, true, Category.OTHER, LocalDate.of(2026, 11, 1), "Salary"),
        exp(7000, true, Category.OTHER, LocalDate.of(2026, 11, 15), "Refund")
    )

    @Test
    fun monthlyTotals_countsOnlyThatMonth() {
        val t = Stats.monthTotals(sample, nov2026)
        assertEquals(157000L, t.incomeMinor)
        assertEquals(35000L, t.spentMinor)
        assertEquals(122000L, t.balanceMinor)
    }

    @Test
    fun categoryTotals_sumsAndSortsDescending() {
        val totals = Stats.categoryTotals(sample, nov2026)
        assertEquals(2, totals.size)
        assertEquals(Category.HOUSING, totals[0].category)
        assertEquals(20000L, totals[0].spentMinor)
        assertEquals(Category.FOOD, totals[1].category)
        assertEquals(15000L, totals[1].spentMinor)
    }

    @Test
    fun budgetRemaining_andFraction() {
        assertEquals(5000L, Stats.budgetRemaining(20000L, 15000L))
        assertEquals(-5000L, Stats.budgetRemaining(10000L, 15000L))
        assertEquals(0.75f, Stats.budgetFraction(15000L, 20000L), 0.001f)
        assertEquals(1f, Stats.budgetFraction(30000L, 20000L), 0.001f)
        assertEquals(0f, Stats.budgetFraction(1000L, 0L), 0.001f)
    }

    @Test
    fun groupByDate_newestDayFirst() {
        val groups = Stats.groupByDate(sample, nov2026)
        assertEquals(4, groups.size)
        assertEquals(LocalDate.of(2026, 11, 15), groups[0].first)
        assertEquals(LocalDate.of(2026, 11, 1), groups[3].first)
        assertEquals(2, groups[3].second.size)
    }

    @Test
    fun lastMonths_returnsSixOldestFirst() {
        val bars = Stats.lastMonths(sample, nov2026)
        assertEquals(6, bars.size)
        assertEquals("Jun", bars[0].label)
        assertEquals("Nov", bars[5].label)
        assertEquals(35000L, bars[5].spentMinor)
        assertEquals(3000L, bars[4].spentMinor) // October transport
        assertTrue(bars.subList(0, 4).all { it.spentMinor == 0L })
    }

    @Test
    fun search_matchesNoteAndCategory() {
        assertEquals(1, Stats.search(sample, "groceries").size)
        assertEquals(2, Stats.search(sample, "food").size)
        assertEquals(6, Stats.search(sample, "").size)
        assertEquals(0, Stats.search(sample, "zzz").size)
    }
}
