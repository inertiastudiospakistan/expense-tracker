package com.clearledger.expenses

import android.graphics.Bitmap
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.SemanticsNode
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.captureToImage
import androidx.compose.ui.test.hasScrollAction
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.performScrollToIndex
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.clearledger.expenses.data.AppDatabase
import com.clearledger.expenses.data.Category
import com.clearledger.expenses.data.Expense
import com.clearledger.expenses.data.ExpenseRepository
import com.clearledger.expenses.ui.home.HomeScreen
import com.clearledger.expenses.ui.home.HomeViewModel
import com.clearledger.expenses.ui.theme.ClearLedgerTheme
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate

/**
 * Visual QA on the JVM (no emulator exists on this VM, and /dev/kvm is
 * absent, so an emulator is not viable here). Each test renders the real
 * HomeScreen at a real device size, saves a PNG screenshot, and runs an
 * automated overlap check over every visible text node: two leaf text
 * nodes whose bounds intersect are a layout bug.
 *
 * Screenshots land in app/build/test-screenshots/ and are copied to
 * screenshots/ for human inspection.
 */
@RunWith(RobolectricTestRunner::class)
// Robolectric 4.13 only knows SDKs up to 34 — asking for 36 throws
// IllegalArgumentException (UnknownSdk) before any test runs. The app
// itself still targets API 36; this only sets the emulated SDK for tests.
@Config(sdk = [34])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class HomeScreenshotTest {

    @get:Rule
    val rule = createComposeRule()

    private fun seededViewModel(): HomeViewModel {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val repo = ExpenseRepository(db.dao())
        val today = LocalDate.now()
        runBlocking {
            repo.add(Expense(amountMinor = 85000, isIncome = true, category = Category.OTHER.name, dateEpochDay = today.withDayOfMonth(1).toEpochDay(), note = "Salary"))
            repo.add(Expense(amountMinor = 12500, isIncome = false, category = Category.FOOD.name, dateEpochDay = today.toEpochDay(), note = "Groceries at the market"))
            repo.add(Expense(amountMinor = 95000, isIncome = false, category = Category.HOUSING.name, dateEpochDay = today.minusDays(2).toEpochDay(), note = "Rent"))
            repo.add(Expense(amountMinor = 4200, isIncome = false, category = Category.TRANSPORT.name, dateEpochDay = today.minusDays(3).toEpochDay(), note = "Bus pass"))
            repo.add(Expense(amountMinor = 8999, isIncome = false, category = Category.ENTERTAINMENT.name, dateEpochDay = today.minusDays(5).toEpochDay(), note = "Cinema tickets for the whole family"))
            repo.setBudget(Category.FOOD, 40000)
            repo.setBudget(Category.HOUSING, 100000)
        }
        return HomeViewModel(repo)
    }

    private fun renderAndCheck(
        name: String,
        widthDp: Int,
        heightDp: Int,
        dark: Boolean,
        fontScale: Float,
        twoPane: Boolean
    ) {
        val vm = seededViewModel()
        rule.setContent {
            CompositionLocalProvider(
                LocalDensity provides Density(
                    density = LocalDensity.current.density,
                    fontScale = fontScale
                )
            ) {
                ClearLedgerTheme(dark = dark) {
                    Box(
                        modifier = Modifier
                            .size(widthDp.dp, heightDp.dp)
                            .testTag("shot")
                    ) {
                        HomeScreen(
                            viewModel = vm,
                            twoPane = twoPane,
                            onHelp = {},
                            onExportCsv = {}
                        )
                    }
                }
            }
        }
        // Wait for the month's data to reach the UI.
        rule.waitUntil(timeoutMillis = 10_000) {
            rule.onAllNodes(hasText("Spent")).fetchSemanticsNodes().isNotEmpty()
        }
        // The data-driven sections (charts, budgets) only render once the
        // seeded Room data reaches the ViewModel. Wait for it, and print
        // the state so a failure says whether data ever arrived.
        val dataArrived = runCatching {
            rule.waitUntil(timeoutMillis = 10_000) { vm.uiState.value.hasAnyEntries }
        }.isSuccess
        println("DIAGNOSTIC $name dataArrived=$dataArrived uiState=${vm.uiState.value}")
        // Overlap is checked on the first viewport, exactly as a user sees it.
        assertNoTextOverlap()
        assertKeyTextsVisible()
        scrollToTop()
        saveScreenshot(name)
    }

    /** Every leaf text currently composed, for failure diagnostics. */
    private fun collectVisibleTexts(): List<String> {
        val out = mutableListOf<String>()
        fun walk(node: SemanticsNode) {
            textsOf(node)?.let { texts -> out += texts.map { it.text } }
            node.children.forEach(::walk)
        }
        walk(rule.onRoot().fetchSemanticsNode())
        return out
    }

    /**
     * Scroll every scrollable column so that the given LazyColumn item
     * index is visible. A swipe gesture can fling past a narrow card
     * without ever sampling it; indexed scrolling lands exactly on it.
     */
    private fun scrollToItem(index: Int) {
        val nodes = rule.onAllNodes(hasScrollAction())
        val count = nodes.fetchSemanticsNodes().size
        for (i in 0 until count) {
            runCatching { nodes[i].performScrollToIndex(index) }
        }
        rule.waitForIdle()
    }

    private fun assertKeyTextsVisible() {
        // LazyColumn item index of the card holding each section title.
        // Single-pane list: 0 switcher, 1 stats, 2 donut, 3 bars, 4 budgets.
        // Two-pane summary column: the same indices 0-4.
        val sectionIndex = mapOf(
            "ClearLedger" to 0,
            "Spent" to 1,
            "Income" to 1,
            "Balance" to 1,
            "Spending by category" to 2,
            "Last 6 months" to 3,
            "Budgets" to 4,
        )
        for ((text, index) in sectionIndex) {
            scrollToItem(index)
            val found = rule.onAllNodes(hasText(text)).fetchSemanticsNodes().isNotEmpty()
            if (!found) {
                println("DIAGNOSTIC missing='$text' visibleTexts=${collectVisibleTexts()}")
            }
            assertTrue("Expected text '$text' to be visible", found)
        }
    }

    /** Back to the top of every column, so the screenshot shows the home screen's top. */
    private fun scrollToTop() {
        scrollToItem(0)
    }

    // SemanticsConfiguration.getOrNull does not resolve in this Compose
    // version, so read the Text property through contains + operator get.
    private fun textsOf(node: SemanticsNode): List<AnnotatedString>? =
        if (node.config.contains(SemanticsProperties.Text)) {
            node.config[SemanticsProperties.Text]
        } else {
            null
        }

    /** Collects leaf text nodes and fails if any two of them overlap. */
    private fun assertNoTextOverlap() {
        val leaves = mutableListOf<Pair<String, Rect>>()
        fun walk(node: SemanticsNode) {
            val texts = textsOf(node)
            val hasText = texts != null && texts.any { it.text.isNotBlank() }
            val childHasText = node.children.any { child ->
                textsOf(child)?.any { it.text.isNotBlank() } == true
            }
            if (hasText && !childHasText) {
                val label = texts!!.joinToString(" / ") { it.text }
                leaves.add(label to node.boundsInRoot)
            }
            node.children.forEach(::walk)
        }
        walk(rule.onRoot().fetchSemanticsNode())
        val problems = mutableListOf<String>()
        for (i in leaves.indices) {
            for (j in i + 1 until leaves.size) {
                val (aText, a) = leaves[i]
                val (bText, b) = leaves[j]
                if (a.overlaps(b)) {
                    // Ignore 1px rounding touches.
                    val inter = a.intersect(b)
                    if (inter.width > 1f && inter.height > 1f) {
                        problems.add("'$aText' $a overlaps '$bText' $b")
                    }
                }
            }
        }
        if (problems.isNotEmpty()) {
            fail("Overlapping text found:\n" + problems.joinToString("\n"))
        }
    }

    private fun saveScreenshot(name: String) {
        val bitmap = rule.onNodeWithTag("shot").captureToImage().asAndroidBitmap()
        val dir = File("build/test-screenshots").apply { mkdirs() }
        FileOutputStream(File(dir, "$name.png")).use {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
        }
    }

    @Test
    fun smallPhone_light() = renderAndCheck("home-small-phone", 360, 640, dark = false, fontScale = 1.0f, twoPane = false)

    @Test
    fun normalPhone_light() = renderAndCheck("home-phone", 412, 915, dark = false, fontScale = 1.0f, twoPane = false)

    @Test
    fun tablet_wide_twoPane() = renderAndCheck("home-tablet", 800, 1280, dark = false, fontScale = 1.0f, twoPane = true)

    @Test
    fun normalPhone_dark() = renderAndCheck("home-dark", 412, 915, dark = true, fontScale = 1.0f, twoPane = false)

    @Test
    fun smallPhone_largeFont() = renderAndCheck("home-font13", 360, 640, dark = false, fontScale = 1.3f, twoPane = false)
}
