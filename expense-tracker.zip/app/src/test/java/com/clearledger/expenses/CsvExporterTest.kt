package com.clearledger.expenses

import com.clearledger.expenses.data.Category
import com.clearledger.expenses.data.CsvExporter
import com.clearledger.expenses.data.Expense
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class CsvExporterTest {

    @Test
    fun build_writesHeaderAndRowsInDateOrder() {
        val rows = listOf(
            Expense(2, 5000, false, Category.FOOD.name, LocalDate.of(2026, 11, 10).toEpochDay(), "Lunch"),
            Expense(1, 150000, true, Category.OTHER.name, LocalDate.of(2026, 11, 1).toEpochDay(), "Salary")
        )
        val csv = CsvExporter.build(rows)
        val lines = csv.trim().split("\n")
        assertEquals("date,type,category,amount,note", lines[0])
        assertEquals("2026-11-01,income,Other,1500.00,Salary", lines[1])
        assertEquals("2026-11-10,expense,Food,50.00,Lunch", lines[2])
    }

    @Test
    fun build_escapesCommasAndQuotes() {
        val rows = listOf(
            Expense(1, 100, false, Category.OTHER.name, LocalDate.of(2026, 11, 5).toEpochDay(), "Tea, \"best\" stall")
        )
        val csv = CsvExporter.build(rows)
        assertTrue(csv.contains("\"Tea, \"\"best\"\" stall\""))
    }

    @Test
    fun build_emptyList_isHeaderOnly() {
        assertEquals("date,type,category,amount,note\n", CsvExporter.build(emptyList()))
    }
}
