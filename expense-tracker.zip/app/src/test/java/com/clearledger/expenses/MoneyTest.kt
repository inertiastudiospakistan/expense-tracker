package com.clearledger.expenses

import com.clearledger.expenses.data.Money
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale

class MoneyTest {

    @Test
    fun parse_validAmounts_toMinorUnits() {
        assertEquals(1234L, Money.parseToMinor("12.34"))
        assertEquals(1200L, Money.parseToMinor("12"))
        assertEquals(1250L, Money.parseToMinor("12.5"))
        assertEquals(5L, Money.parseToMinor("0.05"))
        assertEquals(10000L, Money.parseToMinor("100.00"))
    }

    @Test
    fun parse_rejectsInvalidInput() {
        assertNull(Money.parseToMinor(""))
        assertNull(Money.parseToMinor("abc"))
        assertNull(Money.parseToMinor("0"))
        assertNull(Money.parseToMinor("-5"))
        assertNull(Money.parseToMinor("12.345"))
    }

    @Test
    fun minorUnitMath_hasNoFloatError() {
        // The classic 0.1 + 0.2 float trap: in minor units it is exact.
        val a = Money.parseToMinor("0.10")!!
        val b = Money.parseToMinor("0.20")!!
        assertEquals(30L, a + b)
        assertEquals("0.30", Money.toDecimalString(a + b))
    }

    @Test
    fun format_usesLocaleCurrency() {
        assertEquals("$12.34", Money.format(1234L, Locale.US))
        assertEquals("$0.00", Money.format(0L, Locale.US))
    }

    @Test
    fun toDecimalString_isAlwaysTwoPlaces() {
        assertEquals("12.34", Money.toDecimalString(1234L))
        assertEquals("12.00", Money.toDecimalString(1200L))
        assertEquals("0.05", Money.toDecimalString(5L))
        assertEquals("-3.50", Money.toDecimalString(-350L))
    }

    @Test
    fun formatCompact_shortensLargeAmounts() {
        val compact = Money.formatCompact(1_250_000L, Locale.US)
        assertTrue(compact.contains("K") || compact.contains("1,250"))
    }
}
