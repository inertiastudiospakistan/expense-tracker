package com.clearledger.expenses.data

import kotlinx.coroutines.flow.Flow

/**
 * Thin repository over the DAO. The ViewModel never touches Room directly,
 * and all stats are computed from plain lists in Stats.kt (unit-testable
 * without Android).
 */
class ExpenseRepository(private val dao: ExpenseDao) {
    fun allExpenses(): Flow<List<Expense>> = dao.all()
    fun allBudgets(): Flow<List<Budget>> = dao.budgets()

    suspend fun add(expense: Expense): Long = dao.insert(expense)
    suspend fun update(expense: Expense) = dao.update(expense)
    suspend fun delete(expense: Expense) = dao.delete(expense)
    suspend fun clearAll() {
        dao.clearAll()
        dao.clearBudgets()
    }

    suspend fun setBudget(category: Category, monthlyMinor: Long) {
        dao.setBudget(Budget(category.name, monthlyMinor))
    }

    suspend fun insertSampleMonth() {
        val today = java.time.LocalDate.now()
        val samples = listOf(
            Triple(Category.FOOD, 1250L, "Groceries"),
            Triple(Category.TRANSPORT, 800L, "Bus pass"),
            Triple(Category.HOUSING, 9500L, "Rent share"),
            Triple(Category.FOOD, 450L, "Lunch"),
            Triple(Category.SHOPPING, 2300L, "Shoes"),
            Triple(Category.HEALTH, 1500L, "Pharmacy"),
            Triple(Category.ENTERTAINMENT, 900L, "Cinema")
        )
        samples.forEachIndexed { index, (cat, amount, note) ->
            dao.insert(
                Expense(
                    amountMinor = amount,
                    isIncome = false,
                    category = cat.name,
                    dateEpochDay = today.minusDays((index % 12).toLong()).toEpochDay(),
                    note = note
                )
            )
        }
        dao.insert(
            Expense(
                amountMinor = 85000L, isIncome = true,
                category = Category.OTHER.name,
                dateEpochDay = today.withDayOfMonth(1).toEpochDay(),
                note = "Salary"
            )
        )
    }
}
