package com.clearledger.expenses.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.clearledger.expenses.data.Money
import com.clearledger.expenses.data.Stats

/**
 * Charts are drawn by hand — no chart library. Text is never drawn inside
 * Canvas (that is where clipping bugs live); labels are real Compose Text
 * next to the drawing, so font scaling can never break them.
 */
@Composable
fun DonutChart(totals: List<Stats.CategoryTotal>, totalSpentMinor: Long) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(148.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(148.dp)) {
                val strokePx = 26f
                val inset = strokePx / 2f + 2f
                val arcSize = Size(size.minDimension - inset * 2, size.minDimension - inset * 2)
                var start = -90f
                for (t in totals) {
                    val sweep = if (totalSpentMinor > 0) {
                        t.spentMinor.toFloat() / totalSpentMinor.toFloat() * 360f
                    } else 0f
                    if (sweep > 0f) {
                        drawArc(
                            color = t.category.color,
                            startAngle = start,
                            sweepAngle = (sweep - 3f).coerceAtLeast(0f),
                            useCenter = false,
                            topLeft = Offset(inset, inset),
                            size = arcSize,
                            style = Stroke(width = strokePx)
                        )
                    }
                    start += sweep
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "Spent",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    Money.formatCompact(totalSpentMinor),
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Spacer(Modifier.width(16.dp))
        Column(modifier = Modifier.weight(1f)) {
            for (t in totals) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Canvas(modifier = Modifier.size(10.dp)) {
                        drawCircle(color = t.category.color)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        t.category.label,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        Money.formatCompact(t.spentMinor),
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun BarsChart(months: List<Stats.MonthBar>) {
    val max = months.maxOfOrNull { it.spentMinor }?.coerceAtLeast(1L) ?: 1L
    val barColor = Color(0xFF4A7C59)
    val barColorLight = Color(0xFF9DBE9B)
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            for (m in months) {
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.Bottom
                ) {
                    val fraction = m.spentMinor.toFloat() / max.toFloat()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.55f)
                            .height((8 + fraction * 88).dp)
                            .background(
                                color = if (m.spentMinor == max && max > 0) barColor else barColorLight,
                                shape = RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)
                            )
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth()) {
            for (m in months) {
                Text(
                    m.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
