package com.clearledger.expenses.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.clearledger.expenses.data.Budget
import com.clearledger.expenses.data.Category
import com.clearledger.expenses.data.CsvExporter
import com.clearledger.expenses.data.Expense
import com.clearledger.expenses.data.ExpenseRepository
import com.clearledger.expenses.data.Money
import com.clearledger.expenses.data.Stats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth

enum class TypeFilter { ALL, EXPENSE, INCOME }

data class HomeUiState(
    val month: YearMonth = YearMonth.now(),
    val totals: Stats.MonthTotals = Stats.MonthTotals(0, 0),
    val categoryTotals: List<Stats.CategoryTotal> = emptyList(),
    val lastMonths: List<Stats.MonthBar> = emptyList(),
    val grouped: List<Pair<LocalDate, List<Expense>>> = emptyList(),
    val budgets: Map<String, Long> = emptyMap(),
    val hasAnyEntries: Boolean = false,
    val query: String = "",
    val typeFilter: TypeFilter = TypeFilter.ALL,
    val categoryFilter: Category? = null,
    val allExpenses: List<Expense> = emptyList()
)

/**
 * MVVM: the ViewModel owns UI state and talks to the Repository. It never
 * touches Room or Compose. Stats are pure functions in Stats.kt.
 */
class HomeViewModel(private val repo: ExpenseRepository) : ViewModel() {

    private val monthFlow = MutableStateFlow(YearMonth.now())
    private val queryFlow = MutableStateFlow("")
    private val typeFlow = MutableStateFlow(TypeFilter.ALL)
    private val categoryFlow = MutableStateFlow<Category?>(null)

    @Suppress("UNCHECKED_CAST")
    val uiState: StateFlow<HomeUiState> = combine(
        repo.allExpenses(), repo.allBudgets(), monthFlow, queryFlow, typeFlow, categoryFlow
    ) { args ->
        // NOTE: the 6-flow typed combine() overload does not resolve here —
        // the compiler falls back to the vararg form, whose lambda gets a
        // single Array<Any?>. So the six values are unpacked by position
        // with explicit casts instead of named lambda parameters.
        val expenses = args[0] as List<Expense>
        val budgets = args[1] as List<Budget>
        val month = args[2] as YearMonth
        val query = args[3] as String
        val type = args[4] as TypeFilter
        val category = args[5] as Category?
        val monthExpenses = expenses.filter {
            YearMonth.from(LocalDate.ofEpochDay(it.dateEpochDay)) == month
        }
        val filtered = Stats.search(monthExpenses, query)
            .filter { type == TypeFilter.ALL || (type == TypeFilter.INCOME) == it.isIncome }
            .filter { category == null || it.category == category.name }
        HomeUiState(
            month = month,
            totals = Stats.monthTotals(expenses, month),
            categoryTotals = Stats.categoryTotals(expenses, month),
            lastMonths = Stats.lastMonths(expenses, month),
            grouped = Stats.groupByDate(filtered, month),
            budgets = budgets.associate { it.category to it.monthlyBudgetMinor },
            hasAnyEntries = expenses.isNotEmpty(),
            query = query,
            typeFilter = type,
            categoryFilter = category,
            allExpenses = expenses
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    fun shiftMonth(deltaMonths: Long) {
        monthFlow.value = monthFlow.value.plusMonths(deltaMonths)
    }

    fun goToCurrentMonth() {
        monthFlow.value = YearMonth.now()
    }

    fun setQuery(q: String) { queryFlow.value = q }
    fun setTypeFilter(t: TypeFilter) { typeFlow.value = t }
    fun setCategoryFilter(c: Category?) { categoryFlow.value = c }

    fun saveEntry(
        existing: Expense?,
        amountText: String,
        isIncome: Boolean,
        category: Category,
        date: LocalDate,
        note: String
    ): Boolean {
        val minor = Money.parseToMinor(amountText) ?: return false
        val entry = Expense(
            id = existing?.id ?: 0,
            amountMinor = minor,
            isIncome = isIncome,
            category = if (isIncome) Category.OTHER.name else category.name,
            dateEpochDay = date.toEpochDay(),
            note = note.trim().take(80)
        )
        viewModelScope.launch {
            if (existing == null) repo.add(entry) else repo.update(entry)
        }
        return true
    }

    fun deleteEntry(entry: Expense) {
        viewModelScope.launch { repo.delete(entry) }
    }

    fun setBudget(category: Category, amountText: String) {
        val minor = if (amountText.isBlank()) 0L else Money.parseToMinor(amountText) ?: return
        viewModelScope.launch { repo.setBudget(category, minor) }
    }

    fun clearAll() {
        viewModelScope.launch { repo.clearAll() }
    }

    fun addSampleData() {
        viewModelScope.launch { repo.insertSampleMonth() }
    }

    fun exportCsv(): String = CsvExporter.build(uiState.value.allExpenses)
}
