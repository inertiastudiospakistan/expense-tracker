package com.clearledger.expenses

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.clearledger.expenses.ui.home.HelpScreen
import com.clearledger.expenses.ui.home.HomeScreen
import com.clearledger.expenses.ui.home.HomeViewModel
import com.clearledger.expenses.ui.theme.ClearLedgerTheme

/**
 * Navigation is deliberately state-based (Home <-> Help), not a NavHost:
 * this app has two screens and a bottom sheet — a navigation graph would be
 * ceremony for ceremony's sake, and it keeps this app's structure visibly
 * different from App #1.
 */
class MainActivity : ComponentActivity() {

    private lateinit var viewModelRef: HomeViewModel

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        val csv = viewModelRef.exportCsv()
        contentResolver.openOutputStream(uri)?.use { it.write(csv.toByteArray()) }
    }

    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ClearLedgerTheme {
                val app = application as ClearLedgerApp
                val factory = remember {
                    object : ViewModelProvider.Factory {
                        @Suppress("UNCHECKED_CAST")
                        override fun <T : ViewModel> create(modelClass: Class<T>): T =
                            HomeViewModel(app.repository) as T
                    }
                }
                val vm: HomeViewModel = viewModel(factory = factory)
                viewModelRef = vm
                val windowSize = calculateWindowSizeClass(this)
                val twoPane = windowSize.widthSizeClass >= WindowWidthSizeClass.Medium
                var showHelp by remember { mutableStateOf(false) }
                if (showHelp) {
                    HelpScreen(onBack = { showHelp = false })
                } else {
                    HomeScreen(
                        viewModel = vm,
                        twoPane = twoPane,
                        onHelp = { showHelp = true },
                        onExportCsv = { exportLauncher.launch("clearledger-expenses.csv") }
                    )
                }
            }
        }
    }
}
