package com.clearledger.expenses.data

import java.time.LocalDate
import java.time.format.DateTimeFormatter

/** Builds a plain CSV string for export. No file I/O here — the UI writes it
 *  through the system file picker, so no storage permission is needed. */
object CsvExporter {
    private val dateFmt = DateTimeFormatter.ISO_LOCAL_DATE

    fun build(expenses: List<Expense>): String {
        val sb = StringBuilder()
        sb.append("date,type,category,amount,note\n")
        val sorted = expenses.sortedWith(
            compareBy<Expense> { it.dateEpochDay }.thenBy { it.id }
        )
        for (e in sorted) {
            val date = LocalDate.ofEpochDay(e.dateEpochDay).format(dateFmt)
            val type = if (e.isIncome) "income" else "expense"
            val category = Category.fromName(e.category).label
            sb.append(date).append(',')
                .append(type).append(',')
                .append(escape(category)).append(',')
                .append(Money.toDecimalString(e.amountMinor)).append(',')
                .append(escape(e.note)).append('\n')
        }
        return sb.toString()
    }

    private fun escape(value: String): String {
        if (value.none { it == ',' || it == '"' || it == '\n' }) return value
        return "\"" + value.replace("\"", "\"\"") + "\""
    }
}
