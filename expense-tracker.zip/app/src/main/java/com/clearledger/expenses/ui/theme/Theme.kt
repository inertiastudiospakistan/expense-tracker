package com.clearledger.expenses.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * ClearLedger visual identity: soft sage green + warm cream. Deliberately
 * different from App #1 (navy/amber). Cards are white on cream, 16dp corners,
 * generous padding. Dark theme is a deep green-grey, not a plain black invert.
 */
private val Sage = Color(0xFF4A7C59)
private val SageDark = Color(0xFF3A6247)
private val SageSoft = Color(0xFFE3EDE2)
private val Cream = Color(0xFFFAF6EF)
private val CardWhite = Color(0xFFFFFFFF)
private val Ink = Color(0xFF22301F)
private val InkMuted = Color(0xFF5F6B5A)
private val ExpenseRed = Color(0xFFA63A2E)
private val IncomeGreen = Color(0xFF2F6B3E)

private val DarkSage = Color(0xFF8FBF9A)
private val DarkBackground = Color(0xFF141A15)
private val DarkSurface = Color(0xFF1F2822)
private val DarkInk = Color(0xFFEDEBE3)
private val DarkMuted = Color(0xFFA9B3A4)

private val LightColors = lightColorScheme(
    primary = Sage,
    onPrimary = Color.White,
    primaryContainer = SageSoft,
    onPrimaryContainer = SageDark,
    secondary = SageDark,
    background = Cream,
    onBackground = Ink,
    surface = CardWhite,
    onSurface = Ink,
    surfaceVariant = Color(0xFFF0EBDD),
    onSurfaceVariant = InkMuted,
    error = ExpenseRed,
    outline = Color(0xFFD8D2C0)
)

private val DarkColors = darkColorScheme(
    primary = DarkSage,
    onPrimary = Color(0xFF122015),
    primaryContainer = Color(0xFF2A4030),
    onPrimaryContainer = Color(0xFFD5E8D4),
    secondary = DarkSage,
    background = DarkBackground,
    onBackground = DarkInk,
    surface = DarkSurface,
    onSurface = DarkInk,
    surfaceVariant = Color(0xFF2A332D),
    onSurfaceVariant = DarkMuted,
    error = Color(0xFFE08A7A),
    outline = Color(0xFF3A463C)
)

private val LedgerShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp)
)

// Clean system sans, slightly roomier line heights so large fonts don't clip.
private val LedgerTypography = Typography(
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 23.sp),
    titleSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 23.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 15.sp)
)

@Composable
fun ClearLedgerTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = LedgerTypography,
        shapes = LedgerShapes,
        content = content
    )
}

/** Amount colours: expenses in a muted red, income in deep green. */
@Composable
fun expenseColor(): Color =
    if (isSystemInDarkTheme()) Color(0xFFE08A7A) else ExpenseRed

@Composable
fun incomeColor(): Color =
    if (isSystemInDarkTheme()) Color(0xFF9CCB9F) else IncomeGreen
