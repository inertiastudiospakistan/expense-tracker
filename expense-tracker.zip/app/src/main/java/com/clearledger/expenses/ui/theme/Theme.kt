package com.clearledger.expenses.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * ClearLedger visual identity, second pass: Apple-grade.
 *
 * The first pass (sage green + cream) read as a nice indie app. This pass
 * follows Apple's Human Interface Guidelines the way an official Apple app
 * does: iOS system colours, grouped-list cards on a grey background, an
 * 8pt spacing grid, hairline separators, and the SF type scale with tight
 * tracking on large sizes. Nothing decorative, everything measured.
 *
 * Light: grouped background #F2F2F7, white cards, black label text,
 * secondary #6E6E73, Apple blue #007AFF accent, green #34C759 income,
 * red #FF3B30 expense.
 * Dark: true black #000000 background, #1C1C1E cards, #0A84FF accent,
 * green #30D158, red #FF453A — the way iOS dark mode actually looks.
 */
private val AppleBlue = Color(0xFF007AFF)
private val AppleBlueDark = Color(0xFF0A84FF)
private val SystemGroupedBg = Color(0xFFF2F2F7)
private val SystemGray5 = Color(0xFFE9E9EE)
private val SystemGray2 = Color(0xFFAEAEB2)
private val SecondaryLabel = Color(0xFF6E6E73)
private val TertiaryLabel = Color(0xFF8E8E93)
private val Separator = Color(0xFFC6C6C8)
private val IncomeGreen = Color(0xFF34C759)
private val ExpenseRed = Color(0xFFFF3B30)

private val DarkBackground = Color(0xFF000000)
private val DarkSurface = Color(0xFF1C1C1E)
private val DarkSurfaceVariant = Color(0xFF2C2C2E)
private val DarkSecondaryLabel = Color(0xFF98989D)
private val DarkSeparator = Color(0xFF38383A)
private val DarkIncomeGreen = Color(0xFF30D158)
private val DarkExpenseRed = Color(0xFFFF453A)

private val LightColors = lightColorScheme(
    primary = AppleBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6E9FF),
    onPrimaryContainer = Color(0xFF0040A1),
    secondary = AppleBlue,
    background = SystemGroupedBg,
    onBackground = Color.Black,
    surface = Color.White,
    onSurface = Color.Black,
    surfaceVariant = SystemGray5,
    onSurfaceVariant = SecondaryLabel,
    error = ExpenseRed,
    outline = Separator,
    outlineVariant = Color(0xFFE5E5EA)
)

private val DarkColors = darkColorScheme(
    primary = AppleBlueDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF003A6B),
    onPrimaryContainer = Color(0xFFBDDDFF),
    secondary = AppleBlueDark,
    background = DarkBackground,
    onBackground = Color.White,
    surface = DarkSurface,
    onSurface = Color.White,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkSecondaryLabel,
    error = DarkExpenseRed,
    outline = DarkSeparator,
    outlineVariant = Color(0xFF2C2C2E)
)

private val LedgerShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp)
)

// SF type scale: large title 34 bold with tight tracking, title 22/20 bold,
// headline 17 semibold, body 17, subheadline 15, footnote 13, caption 12.
// Line heights are SF's own (roughly 1.2x), so large fonts never clip.
private val LedgerTypography = Typography(
    displayLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 34.sp, lineHeight = 41.sp, letterSpacing = (-0.5).sp),
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 28.sp, lineHeight = 34.sp, letterSpacing = (-0.3).sp),
    titleLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 25.sp),
    titleSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 17.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 13.sp, lineHeight = 18.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp)
)

@Composable
fun ClearLedgerTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = LedgerTypography,
        shapes = LedgerShapes,
        content = content
    )
}

/** Amount colours: iOS system red for expenses, system green for income. */
@Composable
fun expenseColor(): Color =
    if (isSystemInDarkTheme()) DarkExpenseRed else ExpenseRed

@Composable
fun incomeColor(): Color =
    if (isSystemInDarkTheme()) DarkIncomeGreen else IncomeGreen

/** Tertiary label grey (captions, placeholders, chevrons). */
@Composable
fun tertiaryLabelColor(): Color =
    if (isSystemInDarkTheme()) DarkSecondaryLabel else TertiaryLabel
