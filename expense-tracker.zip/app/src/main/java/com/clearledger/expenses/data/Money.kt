package com.clearledger.expenses.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs

/**
 * Money is stored and computed ONLY as integer minor units (cents/paisa).
 * No Double ever touches an amount: "0.1 + 0.2" style float errors are
 * impossible by construction. 1 unit of currency = 100 minor units.
 */
object Money {
    private const val MINOR_PER_MAJOR = 100L

    /** Parses user input like "12.34", "12", "12.5" -> 1234. Returns null if invalid. */
    fun parseToMinor(text: String): Long? {
        val clean = text.trim().replace(",", "").replace(" ", "")
        if (clean.isEmpty()) return null
        val value = try {
            BigDecimal(clean)
        } catch (_: NumberFormatException) {
            return null
        }
        if (value <= BigDecimal.ZERO) return null
        if (value.scale() > 2) return null
        val minor = value.multiply(BigDecimal(MINOR_PER_MAJOR))
            .setScale(0, RoundingMode.HALF_UP).toLong()
        return if (minor > 0) minor else null
    }

    /** Formats minor units using the device locale currency, e.g. $12.34 */
    fun format(minor: Long, locale: Locale = Locale.getDefault()): String {
        val fmt = NumberFormat.getCurrencyInstance(locale)
        fmt.maximumFractionDigits = 2
        fmt.minimumFractionDigits = 2
        return fmt.format(minor / 100.0)
    }

    /** Compact form for summary cards: $1.2K, $45, -$120. Never clips: short by design. */
    fun formatCompact(minor: Long, locale: Locale = Locale.getDefault()): String {
        val symbol = NumberFormat.getCurrencyInstance(locale).currency?.symbol ?: "$"
        val major = abs(minor) / 100.0
        val sign = if (minor < 0) "-" else ""
        return when {
            major >= 1_000_000 -> "$sign$symbol%.1fM".format(major / 1_000_000)
            major >= 10_000 -> "$sign$symbol%.1fK".format(major / 1_000)
            major >= 1_000 -> "$sign$symbol%,.0f".format(major)
            else -> format(minor, locale)
        }
    }

    /** Plain decimal for CSV export, always two places: 12.34 */
    fun toDecimalString(minor: Long): String {
        val sign = if (minor < 0) "-" else ""
        val a = abs(minor)
        return "$sign${a / 100}.${(a % 100).toString().padStart(2, '0')}"
    }
}
