package com.clearledger.expenses.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clearledger.expenses.data.Category
import com.clearledger.expenses.data.Expense
import com.clearledger.expenses.data.Money
import com.clearledger.expenses.data.Stats
import com.clearledger.expenses.ui.theme.expenseColor
import com.clearledger.expenses.ui.theme.incomeColor
import com.clearledger.expenses.ui.theme.tertiaryLabelColor
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Home screen, Apple-grade pass.
 *
 * The layout follows the iOS grouped-list idiom the way Apple's own apps
 * do: a small nav-bar title with a blue + action (no floating button —
 * Apple does not do FABs), a 34pt large title, one white card holding
 * Spent / Income / Balance behind hairline dividers, an iOS search field,
 * a segmented control for All / Expenses / Income, filter pills, and
 * entries grouped by day inside white cards with inset separators.
 * Everything sits on the 8pt grid: 16dp margins, 16dp gaps between
 * sections, 12dp card corners, 0.5dp hairlines.
 */
fun categoryIcon(category: Category): ImageVector = when (category) {
    Category.FOOD -> Icons.Filled.Restaurant
    Category.TRANSPORT -> Icons.Filled.DirectionsCar
    Category.HOUSING -> Icons.Filled.Home
    Category.SHOPPING -> Icons.Filled.ShoppingBag
    Category.HEALTH -> Icons.Filled.Favorite
    Category.ENTERTAINMENT -> Icons.Filled.Movie
    Category.OTHER -> Icons.Filled.Category
}

private val monthFmt = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)
private val dayFmt = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH)

private fun dayLabel(date: LocalDate): String {
    val today = LocalDate.now()
    return when (date) {
        today -> "Today"
        today.minusDays(1) -> "Yesterday"
        else -> date.format(dayFmt)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    twoPane: Boolean,
    onHelp: () -> Unit,
    onExportCsv: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var menuOpen by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Expense?>(null) }
    var showBudgets by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<Expense?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ClearLedger", style = MaterialTheme.typography.titleSmall) },
                actions = {
                    IconButton(onClick = { editing = null; showAdd = true }) {
                        Icon(
                            Icons.Filled.Add,
                            contentDescription = "Add entry",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(onClick = onHelp) {
                        Icon(Icons.Filled.HelpOutline, contentDescription = "Help")
                    }
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "More options")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Budgets") },
                            onClick = { menuOpen = false; showBudgets = true }
                        )
                        DropdownMenuItem(
                            text = { Text("Export CSV") },
                            onClick = { menuOpen = false; onExportCsv() }
                        )
                        DropdownMenuItem(
                            text = { Text("Add sample data") },
                            onClick = { menuOpen = false; viewModel.addSampleData() }
                        )
                        DropdownMenuItem(
                            text = { Text("Clear all data") },
                            onClick = { menuOpen = false; confirmClear = true }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        if (twoPane) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    largeTitleItem()
                    listItems(state, viewModel) { editing = it; showAdd = true }
                }
                Spacer(Modifier.width(16.dp))
                LazyColumn(
                    modifier = Modifier.weight(0.85f),
                    contentPadding = PaddingValues(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    summaryItems(state, viewModel)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                largeTitleItem()
                summaryItems(state, viewModel)
                listItems(state, viewModel) { editing = it; showAdd = true }
            }
        }
    }

    if (showAdd) {
        AddEditSheet(
            existing = editing,
            onDismiss = { showAdd = false },
            onSave = { amount, isIncome, category, date, note ->
                if (viewModel.saveEntry(editing, amount, isIncome, category, date, note)) {
                    showAdd = false
                }
            },
            onDelete = if (editing != null) {
                { deleteTarget = editing; showAdd = false }
            } else null
        )
    }
    if (showBudgets) {
        BudgetSheet(
            state = state,
            onDismiss = { showBudgets = false },
            onSetBudget = { cat, text -> viewModel.setBudget(cat, text) }
        )
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear all data?") },
            text = { Text("This deletes every entry and budget. It cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { confirmClear = false; viewModel.clearAll() }) {
                    Text("Delete all")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Cancel") }
            }
        )
    }
    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete this entry?") },
            text = { Text("This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { viewModel.deleteEntry(target); deleteTarget = null }) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
            }
        )
    }
}

/** iOS large title: 34pt bold, tight tracking, at the top of the content. */
private fun LazyListScope.largeTitleItem() {
    item {
        Text(
            "ClearLedger",
            style = MaterialTheme.typography.displayLarge,
            modifier = Modifier.padding(top = 4.dp, bottom = 4.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** Summary side: month switcher, totals, charts, budgets. */
private fun LazyListScope.summaryItems(state: HomeUiState, viewModel: HomeViewModel) {
    item {
        MonthSwitcher(
            month = state.month,
            isCurrent = state.month == YearMonth.now(),
            onPrev = { viewModel.shiftMonth(-1) },
            onNext = { viewModel.shiftMonth(1) },
            onToday = { viewModel.goToCurrentMonth() }
        )
    }
    item {
        SectionCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatColumn(
                    label = "Spent",
                    amount = Money.formatCompact(state.totals.spentMinor),
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .width(0.5.dp)
                        .height(44.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant)
                )
                StatColumn(
                    label = "Income",
                    amount = Money.formatCompact(state.totals.incomeMinor),
                    modifier = Modifier.weight(1f)
                )
                Box(
                    modifier = Modifier
                        .width(0.5.dp)
                        .height(44.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant)
                )
                StatColumn(
                    label = "Balance",
                    amount = Money.formatCompact(state.totals.balanceMinor),
                    modifier = Modifier.weight(1f),
                    negative = state.totals.balanceMinor < 0
                )
            }
        }
    }
    if (state.totals.spentMinor > 0) {
        item {
            SectionCard {
                Text("Spending by category", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                DonutChart(state.categoryTotals, state.totals.spentMinor)
            }
        }
        item {
            SectionCard {
                Text("Last 6 months", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                BarsChart(state.lastMonths)
            }
        }
    }
    val budgetRows = Category.entries.mapNotNull { cat ->
        val spent = state.categoryTotals.firstOrNull { it.category == cat }?.spentMinor ?: 0L
        val budget = state.budgets[cat.name] ?: 0L
        if (spent > 0 || budget > 0) Triple(cat, spent, budget) else null
    }
    if (budgetRows.isNotEmpty()) {
        item {
            SectionCard {
                Text("Budgets", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(12.dp))
                for ((index, row) in budgetRows.withIndex()) {
                    if (index > 0) {
                        HairlineDivider(modifier = Modifier.padding(vertical = 8.dp))
                    }
                    BudgetRow(row.first, row.second, row.third)
                }
            }
        }
    }
}

/** List side: search, filters, grouped history. */
private fun LazyListScope.listItems(
    state: HomeUiState,
    viewModel: HomeViewModel,
    onEdit: (Expense) -> Unit
) {
    item {
        TextField(
            value = state.query,
            onValueChange = { viewModel.setQuery(it) },
            // No fixed height: the field's own 56dp minimum is what keeps
            // its text unclipped. A forced 44dp clipped the "Search notes"
            // placeholder on the emulator (run #4 home screenshot).
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search notes") },
            leadingIcon = {
                Icon(
                    Icons.Filled.Search,
                    contentDescription = null,
                    tint = tertiaryLabelColor()
                )
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent,
                cursorColor = MaterialTheme.colorScheme.primary
            )
        )
    }
    item {
        val selectedIndex = when (state.typeFilter) {
            TypeFilter.ALL -> 0
            TypeFilter.EXPENSE -> 1
            TypeFilter.INCOME -> 2
        }
        SegmentedControl(
            options = listOf("All", "Expenses", "Income"),
            selectedIndex = selectedIndex,
            onSelect = { index ->
                viewModel.setTypeFilter(
                    when (index) {
                        1 -> TypeFilter.EXPENSE
                        2 -> TypeFilter.INCOME
                        else -> TypeFilter.ALL
                    }
                )
            },
            modifier = Modifier.fillMaxWidth()
        )
    }
    item {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Pill(
                    text = "All categories",
                    selected = state.categoryFilter == null,
                    onClick = { viewModel.setCategoryFilter(null) }
                )
            }
            items(Category.entries) { cat ->
                Pill(
                    text = cat.label,
                    selected = state.categoryFilter == cat,
                    onClick = { viewModel.setCategoryFilter(cat) }
                )
            }
        }
    }
    if (!state.hasAnyEntries) {
        item {
            SectionCard {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Nothing here yet", style = MaterialTheme.typography.titleSmall)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Tap + to add your first expense or income.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    } else if (state.grouped.isEmpty()) {
        item {
            SectionCard {
                Text(
                    "No entries match this month or filter.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    } else {
        for ((date, entries) in state.grouped) {
            item {
                val daySpent = entries.filter { !it.isIncome }.sumOf { it.amountMinor }
                val dayIncome = entries.filter { it.isIncome }.sumOf { it.amountMinor }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        dayLabel(date),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        if (dayIncome > 0) "−${Money.format(daySpent)}  +${Money.format(dayIncome)}"
                        else "−${Money.format(daySpent)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column {
                        entries.forEachIndexed { index, entry ->
                            if (index > 0) HairlineDivider(startInset = 56.dp)
                            EntryRow(entry = entry, onClick = { onEdit(entry) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MonthSwitcher(
    month: YearMonth,
    isCurrent: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onToday: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onPrev) {
            Icon(
                Icons.Filled.ChevronLeft,
                contentDescription = "Previous month",
                tint = MaterialTheme.colorScheme.primary
            )
        }
        Text(
            month.format(monthFmt),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (!isCurrent) {
            TextButton(onClick = onToday) { Text("Today") }
        }
        IconButton(onClick = onNext) {
            Icon(
                Icons.Filled.ChevronRight,
                contentDescription = "Next month",
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun StatColumn(label: String, amount: String, modifier: Modifier = Modifier, negative: Boolean = false) {
    Column(modifier = modifier.padding(horizontal = 4.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(2.dp))
        Text(
            amount,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (negative) expenseColor() else MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun BudgetRow(category: Category, spentMinor: Long, budgetMinor: Long) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                category.label,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                if (budgetMinor > 0) {
                    val left = Stats.budgetRemaining(budgetMinor, spentMinor)
                    if (left >= 0) "${Money.format(left)} left" else "${Money.format(-left)} over"
                } else Money.format(spentMinor),
                style = MaterialTheme.typography.bodyMedium,
                color = if (budgetMinor > 0 && spentMinor > budgetMinor) expenseColor()
                else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
        Spacer(Modifier.height(8.dp))
        if (budgetMinor > 0) {
            LinearProgressIndicator(
                progress = { Stats.budgetFraction(spentMinor, budgetMinor) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (spentMinor > budgetMinor) expenseColor() else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.outlineVariant
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "${Money.format(spentMinor)} of ${Money.format(budgetMinor)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun EntryRow(entry: Expense, onClick: () -> Unit) {
    val category = Category.fromName(entry.category)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(category.color),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                categoryIcon(category),
                contentDescription = category.label,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                entry.note.ifBlank { if (entry.isIncome) "Income" else category.label },
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                if (entry.isIncome) "Income" else category.label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            (if (entry.isIncome) "+" else "−") + Money.format(entry.amountMinor),
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.SemiBold,
            color = if (entry.isIncome) incomeColor() else expenseColor(),
            maxLines = 1
        )
    }
}
