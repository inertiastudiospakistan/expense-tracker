package com.clearledger.expenses.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.clearledger.expenses.data.Category
import com.clearledger.expenses.data.Expense
import com.clearledger.expenses.data.Money
import com.clearledger.expenses.data.Stats
import com.clearledger.expenses.ui.theme.expenseColor
import com.clearledger.expenses.ui.theme.incomeColor
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

fun categoryIcon(category: Category): ImageVector = when (category) {
    Category.FOOD -> Icons.Filled.Restaurant
    Category.TRANSPORT -> Icons.Filled.DirectionsCar
    Category.HOUSING -> Icons.Filled.Home
    Category.SHOPPING -> Icons.Filled.ShoppingBag
    Category.HEALTH -> Icons.Filled.Favorite
    Category.ENTERTAINMENT -> Icons.Filled.Movie
    Category.OTHER -> Icons.Filled.Category
}

private val monthFmt = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH)
private val dayFmt = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.ENGLISH)

private fun dayLabel(date: LocalDate): String {
    val today = LocalDate.now()
    return when (date) {
        today -> "Today"
        today.minusDays(1) -> "Yesterday"
        else -> date.format(dayFmt)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    twoPane: Boolean,
    onHelp: () -> Unit,
    onExportCsv: () -> Unit
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var menuOpen by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Expense?>(null) }
    var showBudgets by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<Expense?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ClearLedger") },
                actions = {
                    IconButton(onClick = onHelp) {
                        Icon(Icons.Filled.HelpOutline, contentDescription = "Help")
                    }
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "More options")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Budgets") },
                            onClick = { menuOpen = false; showBudgets = true }
                        )
                        DropdownMenuItem(
                            text = { Text("Export CSV") },
                            onClick = { menuOpen = false; onExportCsv() }
                        )
                        DropdownMenuItem(
                            text = { Text("Add sample data") },
                            onClick = { menuOpen = false; viewModel.addSampleData() }
                        )
                        DropdownMenuItem(
                            text = { Text("Clear all data") },
                            onClick = { menuOpen = false; confirmClear = true }
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = null; showAdd = true }) {
                Icon(Icons.Filled.Add, contentDescription = "Add entry")
            }
        }
    ) { padding ->
        if (twoPane) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    listItems(state, viewModel) { editing = it; showAdd = true }
                }
                Spacer(Modifier.width(16.dp))
                LazyColumn(
                    modifier = Modifier.weight(0.85f),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    summaryItems(state, viewModel)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(bottom = 88.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                summaryItems(state, viewModel)
                listItems(state, viewModel) { editing = it; showAdd = true }
            }
        }
    }

    if (showAdd) {
        AddEditSheet(
            existing = editing,
            onDismiss = { showAdd = false },
            onSave = { amount, isIncome, category, date, note ->
                if (viewModel.saveEntry(editing, amount, isIncome, category, date, note)) {
                    showAdd = false
                }
            },
            onDelete = if (editing != null) {
                { deleteTarget = editing; showAdd = false }
            } else null
        )
    }
    if (showBudgets) {
        BudgetSheet(
            state = state,
            onDismiss = { showBudgets = false },
            onSetBudget = { cat, text -> viewModel.setBudget(cat, text) }
        )
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear all data?") },
            text = { Text("This deletes every entry and budget. It cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { confirmClear = false; viewModel.clearAll() }) {
                    Text("Delete all")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Cancel") }
            }
        )
    }
    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete this entry?") },
            text = { Text("This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { viewModel.deleteEntry(target); deleteTarget = null }) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
            }
        )
    }
}

/** Summary side: month switcher, totals, charts, budgets. */
private fun LazyListScope.summaryItems(state: HomeUiState, viewModel: HomeViewModel) {
    item {
        MonthSwitcher(
            month = state.month,
            isCurrent = state.month == YearMonth.now(),
            onPrev = { viewModel.shiftMonth(-1) },
            onNext = { viewModel.shiftMonth(1) },
            onToday = { viewModel.goToCurrentMonth() }
        )
    }
    item {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatCard(
                label = "Spent",
                amount = Money.formatCompact(state.totals.spentMinor),
                modifier = Modifier.weight(1f)
            )
            StatCard(
                label = "Income",
                amount = Money.formatCompact(state.totals.incomeMinor),
                modifier = Modifier.weight(1f)
            )
            StatCard(
                label = "Balance",
                amount = Money.formatCompact(state.totals.balanceMinor),
                modifier = Modifier.weight(1f),
                negative = state.totals.balanceMinor < 0
            )
        }
    }
    if (state.totals.spentMinor > 0) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Spending by category", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(12.dp))
                    DonutChart(state.categoryTotals, state.totals.spentMinor)
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Last 6 months", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(12.dp))
                    BarsChart(state.lastMonths)
                }
            }
        }
    }
    val budgetRows = Category.entries.mapNotNull { cat ->
        val spent = state.categoryTotals.firstOrNull { it.category == cat }?.spentMinor ?: 0L
        val budget = state.budgets[cat.name] ?: 0L
        if (spent > 0 || budget > 0) Triple(cat, spent, budget) else null
    }
    if (budgetRows.isNotEmpty()) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Budgets", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    for ((cat, spent, budget) in budgetRows) {
                        BudgetRow(cat, spent, budget)
                    }
                }
            }
        }
    }
}

/** List side: search, filters, grouped history. */
private fun LazyListScope.listItems(
    state: HomeUiState,
    viewModel: HomeViewModel,
    onEdit: (Expense) -> Unit
) {
    item {
        OutlinedTextField(
            value = state.query,
            onValueChange = { viewModel.setQuery(it) },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search notes") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true
        )
    }
    item {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = state.typeFilter == TypeFilter.ALL,
                onClick = { viewModel.setTypeFilter(TypeFilter.ALL) },
                label = { Text("All") }
            )
            FilterChip(
                selected = state.typeFilter == TypeFilter.EXPENSE,
                onClick = { viewModel.setTypeFilter(TypeFilter.EXPENSE) },
                label = { Text("Expenses") }
            )
            FilterChip(
                selected = state.typeFilter == TypeFilter.INCOME,
                onClick = { viewModel.setTypeFilter(TypeFilter.INCOME) },
                label = { Text("Income") }
            )
        }
    }
    item {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                FilterChip(
                    selected = state.categoryFilter == null,
                    onClick = { viewModel.setCategoryFilter(null) },
                    label = { Text("All categories") }
                )
            }
            items(Category.entries) { cat ->
                FilterChip(
                    selected = state.categoryFilter == cat,
                    onClick = { viewModel.setCategoryFilter(cat) },
                    label = { Text(cat.label) }
                )
            }
        }
    }
    if (!state.hasAnyEntries) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Nothing here yet", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Tap + to add your first expense or income.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    } else if (state.grouped.isEmpty()) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    "No entries match this month or filter.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(20.dp)
                )
            }
        }
    } else {
        for ((date, entries) in state.grouped) {
            item {
                val daySpent = entries.filter { !it.isIncome }.sumOf { it.amountMinor }
                val dayIncome = entries.filter { it.isIncome }.sumOf { it.amountMinor }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        dayLabel(date),
                        style = MaterialTheme.typography.titleSmall,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        if (dayIncome > 0) "−${Money.format(daySpent)}  +${Money.format(dayIncome)}"
                        else "−${Money.format(daySpent)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }
            items(entries) { entry ->
                EntryRow(entry = entry, onClick = { onEdit(entry) })
            }
        }
    }
}

@Composable
private fun MonthSwitcher(
    month: YearMonth,
    isCurrent: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onToday: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onPrev) {
            Icon(Icons.Filled.ChevronLeft, contentDescription = "Previous month")
        }
        Text(
            month.format(monthFmt),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (!isCurrent) {
            TextButton(onClick = onToday) { Text("Today") }
        }
        IconButton(onClick = onNext) {
            Icon(Icons.Filled.ChevronRight, contentDescription = "Next month")
        }
    }
}

@Composable
private fun StatCard(label: String, amount: String, modifier: Modifier = Modifier, negative: Boolean = false) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                amount,
                style = MaterialTheme.typography.titleMedium,
                color = if (negative) expenseColor() else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun BudgetRow(category: Category, spentMinor: Long, budgetMinor: Long) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                category.label,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                if (budgetMinor > 0) {
                    val left = Stats.budgetRemaining(budgetMinor, spentMinor)
                    if (left >= 0) "${Money.format(left)} left" else "${Money.format(-left)} over"
                } else Money.format(spentMinor),
                style = MaterialTheme.typography.bodySmall,
                color = if (budgetMinor > 0 && spentMinor > budgetMinor) expenseColor()
                else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
        Spacer(Modifier.height(4.dp))
        if (budgetMinor > 0) {
            LinearProgressIndicator(
                progress = { Stats.budgetFraction(spentMinor, budgetMinor) },
                modifier = Modifier.fillMaxWidth(),
                color = if (spentMinor > budgetMinor) expenseColor() else MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(2.dp))
            Text(
                "${Money.format(spentMinor)} of ${Money.format(budgetMinor)}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun EntryRow(entry: Expense, onClick: () -> Unit) {
    val category = Category.fromName(entry.category)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(category.color),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    categoryIcon(category),
                    contentDescription = category.label,
                    tint = androidx.compose.ui.graphics.Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    entry.note.ifBlank { if (entry.isIncome) "Income" else category.label },
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    if (entry.isIncome) "Income" else category.label,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                (if (entry.isIncome) "+" else "−") + Money.format(entry.amountMinor),
                style = MaterialTheme.typography.bodyMedium,
                color = if (entry.isIncome) incomeColor() else expenseColor(),
                maxLines = 1
            )
        }
    }
}
