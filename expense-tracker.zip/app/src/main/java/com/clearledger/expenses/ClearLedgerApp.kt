package com.clearledger.expenses

import android.app.Application
import androidx.room.Room
import com.clearledger.expenses.data.AppDatabase
import com.clearledger.expenses.data.ExpenseRepository

/** Application owns the single Room database. No DI framework: one lazy
 *  repository, constructed here and handed to the ViewModel factory. */
class ClearLedgerApp : Application() {
    val database: AppDatabase by lazy {
        Room.databaseBuilder(this, AppDatabase::class.java, "clearledger.db")
            .fallbackToDestructiveMigration()
            .build()
    }
    val repository: ExpenseRepository by lazy { ExpenseRepository(database.dao()) }
}
