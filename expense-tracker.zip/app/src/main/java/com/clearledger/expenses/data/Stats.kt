package com.clearledger.expenses.data

import java.time.LocalDate
import java.time.YearMonth

/**
 * Pure functions over plain lists — no Android, no Room, no coroutines.
 * Everything here is covered by unit tests in StatsTest.
 */
object Stats {

    data class MonthTotals(val incomeMinor: Long, val spentMinor: Long) {
        val balanceMinor: Long get() = incomeMinor - spentMinor
    }

    data class CategoryTotal(val category: Category, val spentMinor: Long)

    data class MonthBar(val label: String, val spentMinor: Long)

    fun monthTotals(expenses: List<Expense>, month: YearMonth): MonthTotals {
        var income = 0L
        var spent = 0L
        for (e in expenses) {
            if (YearMonth.from(LocalDate.ofEpochDay(e.dateEpochDay)) != month) continue
            if (e.isIncome) income += e.amountMinor else spent += e.amountMinor
        }
        return MonthTotals(income, spent)
    }

    fun categoryTotals(expenses: List<Expense>, month: YearMonth): List<CategoryTotal> {
        val map = mutableMapOf<Category, Long>()
        for (e in expenses) {
            if (e.isIncome) continue
            if (YearMonth.from(LocalDate.ofEpochDay(e.dateEpochDay)) != month) continue
            val cat = Category.fromName(e.category)
            map[cat] = (map[cat] ?: 0L) + e.amountMinor
        }
        return map.entries
            .map { CategoryTotal(it.key, it.value) }
            .sortedByDescending { it.spentMinor }
    }

    /** Remaining budget for a category in a month; negative means over budget. */
    fun budgetRemaining(budgetMinor: Long, spentMinor: Long): Long = budgetMinor - spentMinor

    /** Fraction spent of budget, clamped to 0..1 for the progress bar. */
    fun budgetFraction(spentMinor: Long, budgetMinor: Long): Float {
        if (budgetMinor <= 0) return 0f
        return (spentMinor.toFloat() / budgetMinor.toFloat()).coerceIn(0f, 1f)
    }

    /** Groups a month's expenses by day, newest day first. */
    fun groupByDate(expenses: List<Expense>, month: YearMonth): List<Pair<LocalDate, List<Expense>>> {
        return expenses
            .filter { YearMonth.from(LocalDate.ofEpochDay(it.dateEpochDay)) == month }
            .groupBy { LocalDate.ofEpochDay(it.dateEpochDay) }
            .toList()
            .sortedByDescending { it.first }
            .map { (date, list) -> date to list.sortedByDescending { it.id } }
    }

    /** Last [count] months ending at [endingAt], oldest first, for the bar chart. */
    fun lastMonths(expenses: List<Expense>, endingAt: YearMonth, count: Int = 6): List<MonthBar> {
        val months = (count - 1 downTo 0).map { endingAt.minusMonths(it.toLong()) }
        return months.map { m ->
            val label = m.month.name.take(3).lowercase()
                .replaceFirstChar { it.uppercase() }
            MonthBar(label, monthTotals(expenses, m).spentMinor)
        }
    }

    /** Case-insensitive search over note and category label. */
    fun search(expenses: List<Expense>, query: String): List<Expense> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return expenses
        return expenses.filter {
            it.note.lowercase().contains(q) ||
                Category.fromName(it.category).label.lowercase().contains(q)
        }
    }
}
