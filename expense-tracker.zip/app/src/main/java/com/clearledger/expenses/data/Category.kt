package com.clearledger.expenses.data

import androidx.compose.ui.graphics.Color

/**
 * Seven fixed categories. Colours are the iOS system palette — orange,
 * blue, purple, pink, green, light blue, grey — distinct at a glance and
 * readable on both white and black cards. Icons are resolved in the UI
 * layer by name.
 */
enum class Category(val label: String, val colorHex: Long) {
    FOOD("Food", 0xFFFF9500),
    TRANSPORT("Transport", 0xFF007AFF),
    HOUSING("Housing & Bills", 0xFFAF52DE),
    SHOPPING("Shopping", 0xFFFF2D55),
    HEALTH("Health", 0xFF34C759),
    ENTERTAINMENT("Entertainment", 0xFF5AC8FA),
    OTHER("Other", 0xFF8E8E93);

    val color: Color get() = Color(colorHex)

    companion object {
        fun fromName(name: String): Category =
            entries.firstOrNull { it.name == name } ?: OTHER
    }
}
