package com.clearledger.expenses.data

import androidx.compose.ui.graphics.Color

/**
 * Seven fixed categories. Colours are muted, distinct, and readable on both
 * cream and dark backgrounds. Icons are resolved in the UI layer by name.
 */
enum class Category(val label: String, val colorHex: Long) {
    FOOD("Food", 0xFFD96C4A),
    TRANSPORT("Transport", 0xFF4A7C9B),
    HOUSING("Housing & Bills", 0xFF7D6BA8),
    SHOPPING("Shopping", 0xFFB07E2E),
    HEALTH("Health", 0xFF4A7C59),
    ENTERTAINMENT("Entertainment", 0xFFB85C7A),
    OTHER("Other", 0xFF7A7A72);

    val color: Color get() = Color(colorHex)

    companion object {
        fun fromName(name: String): Category =
            entries.firstOrNull { it.name == name } ?: OTHER
    }
}
