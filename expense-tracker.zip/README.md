# ClearLedger — Expense Tracker

A clean, offline expense tracker. Add income and expenses, see monthly
totals, spending by category, budgets, and a 6-month bar chart. Everything
is stored on the phone; nothing leaves it except a CSV you choose to export.

## How this app differs from App #1 (Saudi EOS calculator)

| | App #1 — EOS calculator | This app — ClearLedger |
|---|---|---|
| Visual identity | Deep navy + amber, dark header | Soft sage green + warm cream, white cards, 16dp corners |
| Navigation | Bottom navigation, 3 tabs | Top app bar + FAB, no tab bar; month arrows, bottom sheets |
| Architecture | MVI (intents, single state) | MVVM + Repository (ViewModel + StateFlow) |
| Navigation code | Navigation Compose graph | State-based screen switch (Home / Help) |
| Charts | Distribution bar | Hand-drawn Canvas donut + Box bar chart |
| Data | One-shot calculation | Room database, history, budgets, search, CSV export |
| Language | Arabic-first, RTL | English only |

## Build

Requires JDK 17 and Android SDK with platform 36.

```bash
export JAVA_HOME=/opt/jdk-17
export ANDROID_HOME=$HOME/Android/Sdk
./gradlew assembleDebug          # app/build/outputs/apk/debug/app-debug.apk
./gradlew bundleRelease          # app/build/outputs/bundle/release/app-release.aab
./gradlew testDebugUnitTest      # unit + Robolectric screenshot tests
```

The release bundle is signed with the debug keystore in `app/debug.keystore`
only so it can be built and verified locally. Play App Signing re-signs the
bundle on upload; the developer creates the real upload key in Play Console.

## Money

All amounts are integer minor units (cents/paisa as `Long`). No `Double`
ever touches money — see `data/Money.kt` and `MoneyTest.kt`.

## Tests

- `MoneyTest` — parsing, formatting, float-error-proof minor-unit math.
- `StatsTest` — monthly/category totals, budgets, date grouping, 6-month bars, search.
- `CsvExporterTest` — CSV format, escaping.
- `HomeScreenshotTest` (Robolectric, native graphics) — renders the real
  home screen at 360×640, 412×915, 800×1280 (two-pane), dark mode, and
  1.3× font scale; saves PNGs to `app/build/test-screenshots/` and fails
  the build if any two visible text nodes overlap.

## Privacy

No accounts, no ads, no analytics, no internet permission. See `PRIVACY.md`.
