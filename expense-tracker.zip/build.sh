#!/usr/bin/env bash
# Local build helper for this machine only.
# The VM's egress proxy uses a custom CA: Java must be told to trust it,
# and Gradle must be given the proxy settings. Credentials are read from
# the environment at runtime (never written to this file or the repo).
set -euo pipefail
cd "$(dirname "$0")"
# Toolchain lives under ~/workspace so it survives VM restarts: /opt is
# ephemeral and was wiped once already (18:30, 20 Nov 2026).
export JAVA_HOME=/home/hatch/workspace/tools/jdk-17
export ANDROID_HOME=/home/hatch/Android/Sdk
export ANDROID_SDK_ROOT=/home/hatch/Android/Sdk
# The daemon runs as root (user.home=/root), so without this it would use
# /root/.gradle and miss the proxy settings in /home/hatch/.gradle.
export GRADLE_USER_HOME=/home/hatch/.gradle
# Force IPv4 for the Gradle client JVM too (see gradle.properties).
export JAVA_OPTS="-Djava.net.preferIPv4Stack=true"

TRUSTSTORE="$HOME/.gradle/egress-truststore.jks"
if [ ! -f "$TRUSTSTORE" ]; then
  mkdir -p "$HOME/.gradle"
  "$JAVA_HOME/bin/keytool" -importcert -noprompt -trustcacerts \
    -alias egress-ca -file /run/hatch/egress-tls/ca-bundle.pem \
    -keystore "$TRUSTSTORE" -storepass changeit 2>/dev/null || true
fi

# Parse proxy URL from the environment (http://user:pass@host:port).
PROXY_URL="${https_proxy:-${HTTPS_PROXY:-}}"
PROXY_HOST="hatch-egress-proxy"; PROXY_PORT="3128"; PROXY_USER=""; PROXY_PASS=""
if [ -n "$PROXY_URL" ]; then
  NO_SCHEME="${PROXY_URL#*://}"
  CREDS="${NO_SCHEME%%@*}"
  HOSTPORT="${NO_SCHEME##*@}"
  PROXY_HOST="${HOSTPORT%%:*}"
  PROXY_PORT="${HOSTPORT##*:}"
  PROXY_USER="${CREDS%%:*}"
  PROXY_PASS="${CREDS#*:}"
fi

EXTRA_ARGS=()
[ -n "$PROXY_USER" ] && EXTRA_ARGS+=("-Dhttps.proxyUser=$PROXY_USER" "-Dhttps.proxyPassword=$PROXY_PASS" "-Dhttp.proxyUser=$PROXY_USER" "-Dhttp.proxyPassword=$PROXY_PASS")

exec /home/hatch/workspace/tools/gradle-8.9/bin/gradle \
  -Dhttps.proxyHost="$PROXY_HOST" -Dhttps.proxyPort="$PROXY_PORT" \
  -Dhttp.proxyHost="$PROXY_HOST" -Dhttp.proxyPort="$PROXY_PORT" \
  -Dhttp.nonProxyHosts="localhost|127.0.0.1" \
  -Dhttps.nonProxyHosts="localhost|127.0.0.1" \
  -Djavax.net.ssl.trustStore="$TRUSTSTORE" \
  -Djavax.net.ssl.trustStorePassword=changeit \
  "${EXTRA_ARGS[@]}" \
  --no-daemon "$@"
