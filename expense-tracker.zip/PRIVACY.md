# ClearLedger Privacy Policy

Last updated: 20 November 2026

ClearLedger is an offline expense tracker. It does not collect, transmit,
store on any server, sell, or share any personal information.

- **What the app stores:** your expense and income entries, category
  budgets, and nothing else. All of it lives in a database on your own
  device and is deleted when you clear the app's data or uninstall it.
- **What the app sends:** nothing. The app has no internet permission,
  no analytics, no advertising SDK, and no account system.
- **Export:** if you choose "Export CSV", the app writes a CSV file to a
  location you pick with the system file picker. That file is yours; the
  app does not send it anywhere.
- **Permissions:** the app requests no permissions.

Contact: the developer's support email is listed on the Play Store page.
