// ClearLedger — Expense Tracker. Settings are deliberately plain: no shared
// template with any other app. Repositories are the standard Google + Maven
// Central pair, nothing exotic.
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "expense-tracker"
include(":app")
