# ClearLedger — Play listing checklist

## App
- Package: `com.clearledger.expenses`
- Version: 1.0.0 (versionCode 1)
- Target SDK 36 (Android 16), min SDK 26, native Kotlin + Jetpack Compose.
- No ads, no in-app purchases, no login, no internet permission.

## Data Safety (Play Console form)
- Does the app collect or share any user data? **No.**
- All data (entries, budgets) stays on the device in a local Room database.
- Export is user-initiated via the system file picker; nothing is uploaded.

## Content rating
- No user-generated content shared with others, no chat, no ads, no
  gambling. Expect **Everyone** (ESRB) / **PEGI 3** — complete the
  questionnaire in Play Console; there is nothing to declare beyond that.

## Privacy policy
- Host `PRIVACY.md` (or its text) at a public URL and paste that URL into
  the store listing. The app collects no data, so the policy is short.

## Store listing — still needed (human / designer work)
- [ ] App icon (512×512) — the in-app icon is a sage ledger mark; export a
      512px version for the listing.
- [ ] Feature graphic (1024×500).
- [ ] Phone screenshots (min 2, 1080×1920 recommended) — take from the
      debug APK on a real phone; the `screenshots/` PNGs in this repo are
      layout-verification renders, not store screenshots.
- [ ] Short description (80 chars) + full description (4000 chars max).
- [ ] Category: Finance. Tags: expense tracker, budget, money manager.

## Release
- Upload `app/build/outputs/bundle/release/app-release.aab`.
- New personal accounts must complete 12-tester closed testing for 14 days
  before applying for production access — that is a Play Console step, not
  a code step. The app itself is fully offline and needs no test accounts.
